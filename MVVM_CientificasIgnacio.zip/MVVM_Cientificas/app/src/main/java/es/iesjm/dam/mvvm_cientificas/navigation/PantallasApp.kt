package es.iesjm.dam.mvvm_cientificas.navigation


//archivo donde se guarda las rutas de las pantallas
sealed class PantallasApp(val ruta:String){
    data object PantallaInicio: PantallasApp("inicio_pantalla")
    data object PantallaLista: PantallasApp("Lista_pantalla")
    data object PantallaDetalle: PantallasApp("detalle_pantalla")

}