//Configura las rutas para las pantallas.

package es.iesjm.dam.mvvm_cientificas.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import es.iesjm.dam.mvvm_cientificas.data.Cientifica
import es.iesjm.dam.mvvm_cientificas.data.CientificasDao
import es.iesjm.dam.mvvm_cientificas.ui.theme.Screens.detalles.DetallesScreen
import es.iesjm.dam.mvvm_cientificas.ui.theme.Screens.inicio.InicioScreen
import es.iesjm.dam.mvvm_cientificas.ui.theme.Screens.lista.ListaScreen
import kotlinx.coroutines.flow.Flow


@Composable
fun AppNavigation(navController: NavHostController) {


    NavHost(navController = navController, startDestination = PantallasApp.PantallaInicio.ruta) {

        //navegacion a pantalla de inicio
        composable(PantallasApp.PantallaInicio.ruta) {
            InicioScreen(
                navegar ={ navController.navigate(route = PantallasApp.PantallaLista.ruta) },
            )
        }
        //navegacion a pantalla de Lista
        composable(PantallasApp.PantallaLista.ruta) {
            ListaScreen(
                navegar ={ navController.navigate(route = PantallasApp.PantallaDetalle.ruta) },
            )
        }
        //navegacion a pantalla de Detalles(Mitad de la lista al final)
        composable(PantallasApp.PantallaDetalle.ruta) {
            DetallesScreen(
                navegar ={ navController.navigate(route = PantallasApp.PantallaLista.ruta) },
            )
        }
    }
}

