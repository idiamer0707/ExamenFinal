package es.iesjm.dam.mvvm_cientificas.ui.theme.Screens.lista

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import es.iesjm.dam.mvvm_cientificas.CientificasAplication
import es.iesjm.dam.mvvm_cientificas.data.Cientifica
import es.iesjm.dam.mvvm_cientificas.data.CientificasDao
import kotlinx.coroutines.flow.Flow

//ViewModel de la lista
class ListaViewModel(private val cientificasDao: CientificasDao): ViewModel(){

    //recoges las cientificas
    fun getFullCientificas(): Flow<List<Cientifica>> = cientificasDao.getAllCientificas()

    companion object {
        val factory : ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val application = (this[APPLICATION_KEY] as CientificasAplication)
                ListaViewModel(application.database.cientificasDao())
            }
        }
    }
}