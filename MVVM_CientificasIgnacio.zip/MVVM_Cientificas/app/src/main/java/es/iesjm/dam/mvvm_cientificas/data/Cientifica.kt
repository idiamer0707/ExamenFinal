package es.iesjm.dam.mvvm_cientificas.data

import androidx.annotation.NonNull
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey


//entidad de cientifica
@Entity(tableName = "cientificas")
data class Cientifica (


    @PrimaryKey(autoGenerate = true) val id: Int,

@NonNull
@ColumnInfo(name = "nombre", defaultValue = "") val nombre: String,

@NonNull
@ColumnInfo(name = "logros", defaultValue = "") val logros: String,

@NonNull
@ColumnInfo(name = "biografia", defaultValue = "") val biografia: String
)