package es.iesjm.dam.mvvm_cientificas.data

import androidx.room.Dao
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface CientificasDao {


    //query que muestra toda la lista de cientificas
    @Query("select * from cientificas")
    fun getAllCientificas(): Flow<List<Cientifica>>


    //query que muestra solo la mitad de la lista de cientificas no me me ocurria otra cosa
    @Query("SELECT * from cientificas where id>=10")
    fun getAllMitad(): Flow<List<Cientifica>>

}