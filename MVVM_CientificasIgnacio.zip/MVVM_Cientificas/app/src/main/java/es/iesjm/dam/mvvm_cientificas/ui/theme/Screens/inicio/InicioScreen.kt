package es.iesjm.dam.mvvm_cientificas.ui.theme.Screens.inicio

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import es.iesjm.dam.mvvm_cientificas.ui.theme.MVVM_CientificasTheme
import es.iesjm.dam.mvvm_cientificas.ui.theme.componets.CientificasTopBar

@Composable
fun InicioScreen(navegar : ()->Unit){


    Scaffold(
        topBar = {CientificasTopBar("Pantalla de inicio",false,{}) },
        modifier = Modifier
    ) { innerPadding ->
        Column(
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(16.dp)
                .fillMaxSize()
        ) {
            Spacer(modifier = Modifier.padding(innerPadding))
           Button(onClick = navegar) {
               Text(text = "Lista de cientificas")
           }
        }
    }
}

@Preview
@Composable
fun InicioPreview(){
    MVVM_CientificasTheme {
        InicioScreen {  }
    }
}