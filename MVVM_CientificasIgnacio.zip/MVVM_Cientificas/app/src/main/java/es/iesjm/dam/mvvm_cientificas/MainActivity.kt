
//Configura la navegación como parte del contenido principal.

package es.iesjm.dam.mvvm_cientificas

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import es.iesjm.dam.mvvm_cientificas.navigation.AppNavigation

import es.iesjm.dam.mvvm_cientificas.ui.theme.MVVM_CientificasTheme


class MainActivity : ComponentActivity() {

    //creamos el nav controler
    private lateinit var navController: NavHostController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            //recuerde su estado
            navController = rememberNavController()

            MVVM_CientificasTheme {
                //se lo pasamos a AppNavigation
                AppNavigation(navController)
            }
        }
    }
}

