package es.iesjm.dam.mvvm_cientificas

import android.app.Application
import es.iesjm.dam.mvvm_cientificas.data.AppDatabase


class CientificasAplication: Application() {
    //cargamos la base de datos usando la que esta en assets/database
    val database: AppDatabase by lazy { AppDatabase.getDatabase(this) }
}