package es.iesjm.dam.mvvm_cientificas.ui.theme.componets

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import es.iesjm.dam.mvvm_cientificas.data.Cientifica
import es.iesjm.dam.mvvm_cientificas.ui.theme.fondo1
import es.iesjm.dam.mvvm_cientificas.ui.theme.fondo2



//Lista que usa las screens para mostrar los datos

@Composable
fun Lista(
    lista: List<Cientifica>,
    modifier: Modifier,
) {
    LazyColumn() {
        itemsIndexed(lista) { index, item ->
            //cambia el color uno si uno no para que quede mas visual
            val backgroundColor = if (index % 2 == 0) fondo1 else fondo2
            ElementoLista(item.nombre,item.logros,item.biografia,backgroundColor)
        }
    }

}

//muestra un elemento de la lista
@Composable
fun ElementoLista(nombre:String,logros:String,biografia:String,color : Color){
    Column(
        modifier = Modifier.fillMaxWidth().background(color),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,

        ) {
        Text(text = "Nombre : $nombre")
        Text(text = "Logros : $logros")
        Text(text = "Biografia : $biografia")
    }

}