package es.iesjm.dam.mvvm_cientificas.ui.theme.Screens.detalles

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import es.iesjm.dam.mvvm_cientificas.CientificasAplication
import es.iesjm.dam.mvvm_cientificas.data.Cientifica
import es.iesjm.dam.mvvm_cientificas.data.CientificasDao
import kotlinx.coroutines.flow.Flow


//viewmodel de la pantalla de detalles(al final mitad de la lista)
class DetallesViewModel(private val cientificasDao: CientificasDao): ViewModel(){

    //recoges las cientificas
    fun getFullCientificas(): Flow<List<Cientifica>> = cientificasDao.getAllMitad()

    companion object {
        val factory : ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val application = (this[APPLICATION_KEY] as CientificasAplication)
                DetallesViewModel(application.database.cientificasDao())
            }
        }
    }
}