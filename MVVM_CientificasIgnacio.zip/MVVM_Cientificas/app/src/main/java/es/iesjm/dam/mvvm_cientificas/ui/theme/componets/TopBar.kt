package es.iesjm.dam.mvvm_cientificas.ui.theme.componets

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import es.iesjm.dam.mvvm_cientificas.R
import es.iesjm.dam.mvvm_cientificas.ui.theme.MVVM_CientificasTheme


//topBar de las screens
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CientificasTopBar(
    title: String,
    canNavigateBack: Boolean,
    onBackClick: (() -> Unit)?,
    modifier: Modifier = Modifier
) {
    //si se puede navegar tendra el icono de la flecha
    if (canNavigateBack) {
        CenterAlignedTopAppBar(
            title = { Text(title) },
            actions = {
                if (onBackClick != null) {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = stringResource(
                                R.string.back
                            )
                        )
                    }
                }
            },
            modifier = modifier
        )
    } else {
        CenterAlignedTopAppBar(
            title = { Text(title) },
            modifier = modifier
        )
    }
}

@Preview
@Composable
fun Preview1(){
    MVVM_CientificasTheme {
        CientificasTopBar("hola",false,{})
    }
}

@Preview
@Composable
fun Preview2(){
    MVVM_CientificasTheme {
        CientificasTopBar("hola",true,{})
    }
}