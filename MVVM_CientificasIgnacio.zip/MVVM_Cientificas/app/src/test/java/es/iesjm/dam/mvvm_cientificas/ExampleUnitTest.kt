package es.iesjm.dam.mvvm_cientificas

import org.junit.Test

import org.junit.Assert.*

/**
 * Ejemplo de prueba de unidad (unitaria) local, que se ejecutará en la máquina de desarrollo (host).
 *
 * Consulte [documentación de prueba] (http://d.android.com/tools/testing).
 */
class ExampleUnitTest {
    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }
}